<?php

return [
    'message' => 'Vi bruker informasjonskapsler (cookies) som lagres i nettleseren din når du besøker nettsiden vår. Ved å fortsette å besøke nettsiden vår eller bruke tjenestene våre, godtar du at vi bruker informasjonskapsler.',
    'agree' => 'Jeg forstår',
];
